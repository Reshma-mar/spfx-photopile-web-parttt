// Type definitions for Microsoft ODSP projects
// Project: ODSP

/// <reference path="odsp-webpack.d.ts" />

/* Global definition for DEBUG builds */ 
declare const DEBUG: boolean;

/* Global definition for UNIT_TEST builds */ 
declare const UNIT_TEST: boolean;