/**
 * @file
 * Photopile Web Part properties interface definition
 *
 * Author: Olivier Carpentier
 */
import { IPhotopileWebPartWebPartProps } from './IPhotopileWebPartWebPartProps';

export interface IPhotopileWebPartProps extends IPhotopileWebPartWebPartProps {
}