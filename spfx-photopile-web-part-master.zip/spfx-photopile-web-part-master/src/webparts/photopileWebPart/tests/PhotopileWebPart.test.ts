import * as assert from 'assert';

describe('PhotopileWebPartWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
